﻿Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass()> _
Public Class Tests

    <TestMethod()> _
    Public Sub TestMethod1()
    End Sub

End Class